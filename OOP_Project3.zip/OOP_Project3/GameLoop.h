﻿#pragma once

int BaseLoop();
int GameLoop();

