#pragma once

void Initialize();
void Process();
void PreRender();
void Render();
void PostRender();
void Release();