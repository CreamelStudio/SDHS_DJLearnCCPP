﻿#pragma once

void DrawBigDot(int x, int y, COLORREF rgb);
void DrawBigBigDot(int x, int y, COLORREF rgb);
void DrawYellowDot(int x, int y);