#pragma once
class NumberData
{
};